import { getStore } from "@netlify/blobs";

export const config = { path: "/sub/*" };

export default async (req) => {
  const id = new URL(req.url).pathname.split("/").pop().replace(/\.txt$/i, "");
  if (!/^[\w-]{10,40}$/.test(id)) return new Response("Not found", { status: 404 });

  const s = await getStore("subs").get(id, { type: "json" });
  if (!s) return new Response("Not found", { status: 404 });

  const total = Math.round(Number(s.gb) * 1073741824);
  const expire = s.expire ? Math.floor(new Date(s.expire + "T23:59:59Z").getTime() / 1000) : 0;
  const userinfo = `upload=0; download=0; total=${total}; expire=${expire}`;

  const head = [
    `#profile-title: ${s.title}`,
    `#profile-update-interval: 1`,
    `#subscription-userinfo: ${userinfo}`,
    `#announce: ${s.announce}`,
    `#profile-web-page-url: ${s.web}`,
    `#support-url: ${s.support}`,
    `#profile-icon: https://telegram.org/img/t_logo.png`,
    `#subscriptions-sort-type: ping`,
    `#hide-settings: 1`,
    `#ping-type: proxy`,
    `#ping-result: time`,
    `#check-url-via-proxy: http://cp.cloudflare.com/generate_204`,
  ].join("\n");

  const headers = {
    "content-type": "text/plain; charset=utf-8",
    "cache-control": "no-store",
    "profile-update-interval": "1",
    "subscription-userinfo": userinfo,
    "profile-title": "base64:" + Buffer.from(s.title || "").toString("base64"),
  };
  if (/^[\x20-\x7e]*$/.test(s.support)) headers["support-url"] = s.support;
  if (/^[\x20-\x7e]*$/.test(s.web)) headers["profile-web-page-url"] = s.web;

  return new Response(head + "\n\n" + s.configs + "\n", { headers });
};
