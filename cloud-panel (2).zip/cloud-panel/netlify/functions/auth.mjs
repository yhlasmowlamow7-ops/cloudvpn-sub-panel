import { getStore } from "@netlify/blobs";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

export const config = { path: "/api/auth/*" };

const json = (d, s = 200) =>
  new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });
const hash = (p, salt) => scryptSync(p, salt, 64);

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Desteklenmeyen istek" }, 405);
  const action = new URL(req.url).pathname.split("/").pop();
  const users = getStore("users");
  const sessions = getStore("sessions");

  if (action === "logout") {
    const t = (req.headers.get("authorization") || "").replace(/^Bearer /, "");
    if (t) await sessions.delete(t);
    return json({ ok: true });
  }

  const b = await req.json().catch(() => ({}));
  const key = String(b.username || "").trim().toLowerCase();
  const pass = String(b.password || "");
  if (!/^[a-z0-9_.-]{3,24}$/.test(key))
    return json({ error: "Kullanıcı adı 3-24 karakter olmalı (harf, rakam, _ . -)." }, 400);
  if (pass.length < 6) return json({ error: "Şifre en az 6 karakter olmalı." }, 400);

  if (action === "register") {
    if (await users.get(key)) return json({ error: "Bu kullanıcı adı alınmış." }, 409);
    const salt = randomBytes(16);
    await users.setJSON(key, {
      name: key,
      salt: salt.toString("hex"),
      hash: hash(pass, salt).toString("hex"),
      created: Date.now(),
    });
  } else if (action === "login") {
    const u = await users.get(key, { type: "json" });
    const ok = u && timingSafeEqual(hash(pass, Buffer.from(u.salt, "hex")), Buffer.from(u.hash, "hex"));
    if (!ok) return json({ error: "Kullanıcı adı veya şifre yanlış." }, 401);
  } else {
    return json({ error: "Bulunamadı" }, 404);
  }

  const token = randomBytes(32).toString("base64url");
  await sessions.setJSON(token, { user: key, exp: Date.now() + 30 * 864e5 });
  return json({ token, username: key });
};
