import { getStore } from "@netlify/blobs";
import { randomBytes } from "node:crypto";
import { userFrom } from "../lib/session.mjs";

export const config = { path: ["/api/subs", "/api/subs/*"] };

const json = (d, s = 200) =>
  new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });

const SCHEMES = /^(vless|vmess|ss|trojan|hysteria2?|hy2|tuic):\/\//i;

function clean(b) {
  const configs = String(b.configs || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (!configs.length) return { error: "En az bir config gerekli." };
  const bad = configs.find((l) => !SCHEMES.test(l));
  if (bad) return { error: "Geçersiz config satırı: " + bad.slice(0, 40) };
  const gb = Number(b.gb);
  if (!(gb >= 0)) return { error: "GB limiti geçersiz." };
  return {
    data: {
      title: String(b.title || "").slice(0, 100),
      configs: configs.join("\n"),
      gb,
      support: String(b.support || "").slice(0, 300),
      web: String(b.web || "").slice(0, 300),
      announce: String(b.announce || "").replace(/[\r\n]+/g, " ").slice(0, 500),
      expire: String(b.expire || "").slice(0, 10),
    },
  };
}

export default async (req) => {
  const user = await userFrom(req);
  if (!user) return json({ error: "Oturum gerekli. Lütfen giriş yap." }, 401);

  const store = getStore("subs");
  const id = new URL(req.url).pathname.split("/").filter(Boolean)[2];

  if (req.method === "GET") {
    const { blobs } = await store.list();
    const all = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
    return json(all.filter((s) => s && s.owner === user).sort((a, b) => b.created - a.created));
  }

  if (req.method === "DELETE" && id) {
    const old = await store.get(id, { type: "json" });
    if (!old || old.owner !== user) return json({ error: "Bulunamadı" }, 404);
    await store.delete(id);
    return json({ ok: true });
  }

  if (req.method === "POST" || req.method === "PUT") {
    const { data, error } = clean(await req.json().catch(() => ({})));
    if (error) return json({ error }, 400);

    if (req.method === "POST") {
      const newId = randomBytes(16).toString("base64url").slice(0, 21);
      const item = { id: newId, owner: user, created: Date.now(), ...data };
      await store.setJSON(newId, item);
      return json(item, 201);
    }

    const old = id && (await store.get(id, { type: "json" }));
    if (!old || old.owner !== user) return json({ error: "Bulunamadı" }, 404);
    const item = { ...old, ...data, id: old.id, owner: old.owner, created: old.created, updated: Date.now() };
    await store.setJSON(id, item);
    return json(item);
  }

  return json({ error: "Desteklenmeyen istek" }, 405);
};
